﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richText1 = new System.Windows.Forms.RichTextBox();
            this.btnContaLetra = new System.Windows.Forms.Button();
            this.btnPrimeiroEspaco = new System.Windows.Forms.Button();
            this.btnContaNumericos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richText1
            // 
            this.richText1.Location = new System.Drawing.Point(187, 51);
            this.richText1.Name = "richText1";
            this.richText1.Size = new System.Drawing.Size(421, 161);
            this.richText1.TabIndex = 0;
            this.richText1.Text = "";
            // 
            // btnContaLetra
            // 
            this.btnContaLetra.Location = new System.Drawing.Point(539, 291);
            this.btnContaLetra.Name = "btnContaLetra";
            this.btnContaLetra.Size = new System.Drawing.Size(178, 72);
            this.btnContaLetra.TabIndex = 9;
            this.btnContaLetra.Text = "Contar Letras";
            this.btnContaLetra.UseVisualStyleBackColor = true;
            this.btnContaLetra.Click += new System.EventHandler(this.btnContaLetra_Click);
            // 
            // btnPrimeiroEspaco
            // 
            this.btnPrimeiroEspaco.Location = new System.Drawing.Point(316, 291);
            this.btnPrimeiroEspaco.Name = "btnPrimeiroEspaco";
            this.btnPrimeiroEspaco.Size = new System.Drawing.Size(178, 72);
            this.btnPrimeiroEspaco.TabIndex = 8;
            this.btnPrimeiroEspaco.Text = "Primeiro espaço";
            this.btnPrimeiroEspaco.UseVisualStyleBackColor = true;
            this.btnPrimeiroEspaco.Click += new System.EventHandler(this.btnPrimeiroEspaco_Click);
            // 
            // btnContaNumericos
            // 
            this.btnContaNumericos.Location = new System.Drawing.Point(88, 291);
            this.btnContaNumericos.Name = "btnContaNumericos";
            this.btnContaNumericos.Size = new System.Drawing.Size(178, 72);
            this.btnContaNumericos.TabIndex = 7;
            this.btnContaNumericos.Text = "Caracteres Numéricos";
            this.btnContaNumericos.UseVisualStyleBackColor = true;
            this.btnContaNumericos.Click += new System.EventHandler(this.btnContaNumericos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContaLetra);
            this.Controls.Add(this.btnPrimeiroEspaco);
            this.Controls.Add(this.btnContaNumericos);
            this.Controls.Add(this.richText1);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richText1;
        private System.Windows.Forms.Button btnContaLetra;
        private System.Windows.Forms.Button btnPrimeiroEspaco;
        private System.Windows.Forms.Button btnContaNumericos;
    }
}
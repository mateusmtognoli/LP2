﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNumericos_Click(object sender, EventArgs e)
        {
            int i = 0;
            int comprimento = richText1.Text.Length;
            int qtdNumeros = 0;
            while (i < comprimento)
            {
                if (Char.IsNumber(richText1.Text[i]))
                {
                    qtdNumeros++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de números: {qtdNumeros}");
        }

        private void btnPrimeiroEspaco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < richText1.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(richText1.Text[i]))
                {
                    MessageBox.Show($"Posição do primeiro caracter em branco: {i + 1}");
                    break;
                }
            }
        }

        private void btnContaLetra_Click(object sender, EventArgs e)
        {
            int qtdLetras = 0;
            foreach (var letra in richText1.Text)
            {
                if(Char.IsLetter(letra)) qtdLetras++;
            }
            
            MessageBox.Show($"Quantidade de letras: {qtdLetras}");
        }
    }
}

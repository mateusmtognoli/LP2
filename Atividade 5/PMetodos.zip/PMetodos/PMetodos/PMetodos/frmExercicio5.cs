﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void lblPalavra1_Click(object sender, EventArgs e)
        {

        }

        private void btnRemoverOcorrencias_Click(object sender, EventArgs e)
        {

        }

        private void txtPalavra2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPalavra1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnInverter_Click(object sender, EventArgs e)
        {
            int num1;
            int num2;
            if(!int.TryParse(txtNum1.Text, out num1) | !int.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Digite números inteiros válidos.");
                return;
            }
            if(num1 >= num2)
            {
                MessageBox.Show("O primeiro número deve ser menor que o segundo.");
                return;
            }
            Random rand = new Random();
            int numSelecionado = rand.Next(num1, num2);
            MessageBox.Show("Número selecionado: " + numSelecionado.ToString());
        }
    }
}

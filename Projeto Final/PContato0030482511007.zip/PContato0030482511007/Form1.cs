﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482511007
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=APOLO;Initial Catalog=BD;Persist Security Info=True;User ID=BD2511007; Password=MMT!240107");
                conexao.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void cadastroContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {
                //MessageBox.Show("Form já existe");
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato objC = new frmContato();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                //MessageBox.Show("Form já existe");
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre objC = new frmSobre();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

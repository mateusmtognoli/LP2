﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482511007
{
    public partial class frmContato : Form
    {

        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();


        public frmContato()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void frmContato_Load(object sender, EventArgs e)
        {

            try 
            {
                Contato Con = new Contato();
                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;

                txtId.DataBindings.Add("TEXT", bnContato, "id_contato");
                txtNome.DataBindings.Add("TEXT", bnContato, "nome_contato");
                txtEndereco.DataBindings.Add("TEXT", bnContato, "end_contato");
                txtCelular.DataBindings.Add("TEXT", bnContato, "cel_contato");
                txtEmail.DataBindings.Add("TEXT", bnContato, "email_contato");
                dtpDtCadastro.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());

                cboxCidade.DataSource = dsCidade.Tables["Cidade"];

                cboxCidade.DisplayMember = "nome_cidade";

                cboxCidade.ValueMember = "id_cidade";

                cboxCidade.DataBindings.Add("SelectedValue", bnContato, "cidade_id_cidade");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }


            bnContato.AddNew();


            txtNome.Enabled = true;

            txtEndereco.Enabled = true;

            cboxCidade.Enabled = true;

            // vai para o primeiro  

            cboxCidade.SelectedIndex = 0;

            txtCelular.Enabled = true;

            txtEmail.Enabled = true;

            dtpDtCadastro.Enabled = true;



            btnNovo.Enabled = false;

            btnAlterar.Enabled = false;

            btnExcluir.Enabled = false;

            btnSalvar.Enabled = true;

            btnCancelar.Enabled = true;



            bInclusao = true;
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }

            txtNome.Enabled = true;

            txtEndereco.Enabled = true;

            cboxCidade.Enabled = true;

            txtCelular.Enabled = true;

            txtEmail.Enabled = true;

            dtpDtCadastro.Enabled = true;



            btnNovo.Enabled = false;

            btnAlterar.Enabled = false;

            btnExcluir.Enabled = false;

            btnSalvar.Enabled = true;

            btnCancelar.Enabled = true;



            bInclusao = false;
        }


        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Nome inválido!");
            }
            else if (txtEndereco.Text == "")
            {
                MessageBox.Show("Endereço inválido!");
            }
            else if (cboxCidade.SelectedIndex == -1)
            {
                MessageBox.Show("Cidade inválida!");
            }
            else if (txtCelular.Text == "")
            {
                MessageBox.Show("Celular inválido!");
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("E-mail inválido!");
            }
            else
            {
                Contato RegCon = new Contato();


                RegCon.Nomecontato = txtNome.Text;

                RegCon.Endcontato = txtEndereco.Text;

                RegCon.Cidadeidcidade = Convert.ToInt32(cboxCidade.SelectedValue.ToString());

                RegCon.Celcontato = txtCelular.Text;

                RegCon.Emailcontato = txtEmail.Text;

                RegCon.Dtcadastrocontato = dtpDtCadastro.Value;



                if (bInclusao)
                {
                    if (RegCon.Incluir() > 0)
                    {
                        MessageBox.Show("Contato adicionado com sucesso!");


                        txtNome.Enabled = false;

                        txtEndereco.Enabled = false;

                        cboxCidade.Enabled = false;

                        txtCelular.Enabled = false;

                        txtEmail.Enabled = false;

                        dtpDtCadastro.Enabled = false;



                        btnNovo.Enabled = true;

                        btnAlterar.Enabled = true;

                        btnExcluir.Enabled = true;

                        btnSalvar.Enabled = false;

                        btnCancelar.Enabled = false;



                        bInclusao = false;

                        // recarrega o grid 

                        dsContato.Tables.Clear();

                        dsContato.Tables.Add(RegCon.Listar());

                        bnContato.DataSource = dsContato.Tables["Contato"];

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar contato!");
                    }

                }
                else
                {

                    RegCon.Idcontato = Convert.ToInt32(txtId.Text);

                    if (RegCon.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterado com sucesso!");


                        txtNome.Enabled = false;

                        txtEndereco.Enabled = false;

                        cboxCidade.Enabled = false;

                        txtCelular.Enabled = false;

                        txtEmail.Enabled = false;

                        dtpDtCadastro.Enabled = false;



                        btnNovo.Enabled = true;

                        btnAlterar.Enabled = true;

                        btnExcluir.Enabled = true;

                        btnSalvar.Enabled = false;

                        btnCancelar.Enabled = false;

                        // recarrega o grid 

                        dsContato.Tables.Clear();

                        dsContato.Tables.Add(RegCon.Listar());

                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar contato!");
                    }
                }
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }


            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Contato RegCon = new Contato();
                RegCon.Idcontato = Convert.ToInt32(txtId.Text);

                if (RegCon.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluído com sucesso!");

                    // recarrega o grid 

                    dsContato.Tables.Clear();

                    dsContato.Tables.Add(RegCon.Listar());

                    bnContato.DataSource = dsContato.Tables["Contato"];
                }

                else
                {
                    MessageBox.Show("Erro ao excluir contato!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();



            txtNome.Enabled = false;

            txtEndereco.Enabled = false;

            cboxCidade.Enabled = false;

            txtCelular.Enabled = false;

            txtEmail.Enabled = false;

            dtpDtCadastro.Enabled = false;



            btnNovo.Enabled = true;

            btnAlterar.Enabled = true;

            btnExcluir.Enabled = true;

            btnSalvar.Enabled = false;

            btnCancelar.Enabled = false;



            bInclusao = false;

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

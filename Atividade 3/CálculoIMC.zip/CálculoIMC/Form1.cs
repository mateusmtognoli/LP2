﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CálculoIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, IMC;

        public Form1()
        {
            InitializeComponent();
        }

        private void mskPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskPeso.Text, out peso))
            {
                errorProvider1.SetError(mskPeso, "Peso inválido!");
                mskPeso.Focus();
            }
            else
            {
                errorProvider1.SetError(mskPeso, "");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskAltura.Text = "";
            mskPeso.Text = "";
            txtIMC.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja mesmo sair?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

            {
                Close();
            }
        }

        private void mskAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskAltura.Text, out altura))
            {
                errorProvider2.SetError(mskAltura, "Altura inválida!");
                mskPeso.Focus();
            }
            else
            {
                errorProvider2.SetError(mskAltura, "");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = peso / Math.Pow(altura, 2);
            IMC = Math.Round(IMC, 1);
            txtIMC.Text = IMC.ToString();
            
                if (IMC < 18.5)
                    MessageBox.Show("Magreza");
                else if (IMC <= 24.9)
                    MessageBox.Show("Normal");
                else if (IMC <= 29.9)
                    MessageBox.Show("Sobrepeso");
                else if (IMC <= 39.9)
                    MessageBox.Show("Obesidade");
                else
                    MessageBox.Show("Obesidade Grave");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulos
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void mktbValorB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mktbLadoB.Text, out ladoB))
            {
                errPLadoB.SetError(mktbLadoB, "Valor Inválido!");
                mktbLadoB.Focus();
            }
            else
            {
                errPLadoB.SetError(mktbLadoB, "");
            }
        }

        //private void mktbLadoC_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(ladoB-ladoC) < ladoA && ladoA < ladoB+ladoC) &&
                (Math.Abs(ladoA-ladoC) < ladoB && ladoB < ladoA+ladoC) &&
                (Math.Abs(ladoA-ladoB) < ladoC && ladoC < ladoA+ladoB))
            {
                MessageBox.Show("Os valores inseridos podem ser lados de um triângulo!");
                {
                    if (ladoA == ladoB && ladoB == ladoC)
                    {
                        txtTipo.Text = "Equilátero";
                    }
                    else if (ladoA != ladoB && ladoB != ladoC && ladoC != ladoA)
                    {
                        txtTipo.Text = "Escaleno";
                    }
                    else
                    {
                        txtTipo.Text = "Isósceles";
                    }
                }
            }
            else
            {
                MessageBox.Show("Os valores inseridos não podem ser lados de um triângulo!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mktbLadoA.Text = "";
            mktbLadoB.Text = "";
            mktbLadoC.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja mesmo sair?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

            {
                Close();
            }
        }

        private void mktbLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mktbLadoC.Text, out ladoC))
            {
                errPLadoC.SetError(mktbLadoC, "Valor Inválido");
                mktbLadoC.Focus();
            }
            else
            {
                errPLadoC.SetError(mktbLadoC, "");
            }
        }

        //private void mktbValorB_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        //{

        //}

        private void mktbValorA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mktbLadoA.Text, out ladoA))
            {
                errPLadoA.SetError(mktbLadoA, "Valor Inválido!");
                mktbLadoA.Focus();
            }
            else
            {
                errPLadoA.SetError(mktbLadoA, "");
            }
        }



        public Form1()
        {
            InitializeComponent();
        }

        //private void Form1_Load(object sender, EventArgs e)
        //{

        //}
    }
}

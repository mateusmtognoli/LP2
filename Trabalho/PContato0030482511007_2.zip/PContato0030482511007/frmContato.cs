﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482511007
{
    public partial class frmContato : Form
    {

        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();


        public frmContato()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void frmContato_Load(object sender, EventArgs e)
        {

            try 
            {
                Contato Con = new Contato();
                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;

                txtId.DataBindings.Add("TEXT", bnContato, "id_contato");
                txtNome.DataBindings.Add("TEXT", bnContato, "nome_contato");
                txtEndereco.DataBindings.Add("TEXT", bnContato, "end_contato");
                txtCelular.DataBindings.Add("TEXT", bnContato, "cel_contato");
                txtEmail.DataBindings.Add("TEXT", bnContato, "email_contato");
                dtpDtCadastro.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());

                cboxCidade.DataSource = dsCidade.Tables["Cidade"];

                cboxCidade.DisplayMember = "nome_cidade";

                cboxCidade.ValueMember = "id_cidade";

                cboxCidade.DataBindings.Add("SelectedValue", bnContato, "cidade_id_cidade");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)

            {

                tbContato.SelectTab(1);

            }



            bnContato.AddNew();



            txtNome.Enabled = true;

            txtEndereco.Enabled = true;

            cboxCidade.Enabled = true;

            // vai para o primeiro  

            cboxCidade.SelectedIndex = 0;

            txtCelular.Enabled = true;

            txtEmail.Enabled = true;

            dtpDtCadastro.Enabled = true;



            btnNovo.Enabled = false;

            btnAlterar.Enabled = false;

            btnExcluir.Enabled = false;

            btnSalvar.Enabled = true;

            btnCancelar.Enabled = true;



            bInclusao = true;
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)

            {

                tbContato.SelectTab(1);

            }



            txtNome.Enabled = true;

            txtEndereco.Enabled = true;

            cboxCidade.Enabled = true;

            txtCelular.Enabled = true;

            txtEmail.Enabled = true;

            dtpDtCadastro.Enabled = true;



            btnNovo.Enabled = false;

            btnAlterar.Enabled = false;

            btnExcluir.Enabled = false;

            btnSalvar.Enabled = true;

            btnCancelar.Enabled = true;



            bInclusao = false;
        }
    }
}

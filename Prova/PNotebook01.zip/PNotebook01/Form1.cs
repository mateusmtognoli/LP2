﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lBox.Items.Clear();
            double auxiliar;
            double preco = 0;
            double[,] matriz = new double[3, 3];
            double[] media = new double[3];

            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    if (!double.TryParse(Interaction.InputBox("Digite os preços: ", "Entrada de Dados"), out auxiliar))
                    {
                        MessageBox.Show("Preço inválido!");
                        j--;
                        continue;
                    }
                    if (auxiliar >= 0)
                    {
                        matriz[i, j] = auxiliar;
                        preco += matriz[i, j];
                    }
                    else
                    {
                        lBox.Items.Add($"Preço na Loja {i + 1}: ", matriz[i, j].ToString("F2"));
                        j--;
                    }
                }
                media[i] = preco / 3;


                }
                for (int i = 0; i < matriz.GetLength(0); i++)
                {
                    lBox.Items.Add($"Media de preços da loja {i + 1}: {media[i].ToString("F2")}");

                }
            }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lBox = "";
        }
    }
}








    //    private void lBox_Validated(object sender, EventArgs e)
    //    {
    //        {
    //            if (!Double.TryParse(lBox.Text, out auxiliar))
    //            {
    //                errorProvider1.SetError(lBox.Text, "Número 1 inválido!");
    //                lBox.Text.Focus();
    //            }
    //            else
    //                errorProvider1.SetError(txtNumero1, "");
    //        }
    //    }
    //}
